

library(terra)
library(sf)
library(geodata)
# make env maps


env = geodata::worldclim_country("Czechia", var="bio", path = "data/")
grid = vect("../cooccurrences/data/all_scales_atlas_5.gpkg")
grid = grid[grid$scalingID==4,]
cz = vect("../cooccurrences/data/czechia.gpkg")

env = terra::crop(env, cz)
plot(env$wc2.1_30s_bio_1)

plot(env$wc2.1_30s_bio_1, breaks=5)


env_grid = extract(env, grid, bind=T, fun="mean", na.rm=T)

library(ggplot2)
set_theme(theme_classic()+
            theme(axis.line = element_blank(),
                  axis.text = element_blank(),
                  axis.ticks = element_blank(),
                  axis.title = element_blank()))
env_grid = st_as_sf(env_grid)

#remove grids with small area
hist(env_grid$area)

env_grid = env_grid[env_grid$area > 1000, ]

ggplot(env_grid, aes(fill=wc2.1_30s_bio_1))+
  geom_sf()+
  scale_fill_binned(n.breaks = 5)
ggsave(filename = "temp.pdf")




# get grid with numbers instead of shading

# Extract coordinates into columns
env_grid$xmin <- sapply(cell_bbox, function(x) x["xmin"])
env_grid$xmax <- sapply(cell_bbox, function(x) x["xmax"])
env_grid$ymin <- sapply(cell_bbox, function(x) x["ymin"])
env_grid$ymax <- sapply(cell_bbox, function(x) x["ymax"])

env_grid$temp_bin <- as.integer(cut(
  env_grid$wc2.1_30s_bio_1,
  breaks = 5,
  labels = 1:5,
  include.lowest = TRUE
))

env_grid$prec_bin <- as.integer(cut(
  env_grid$wc2.1_30s_bio_12,
  breaks = 5,
  labels = 1:5,
  include.lowest = TRUE
))


# Plot
ggplot() +
  geom_sf(data = env_grid, fill = NA, linewidth = 0.7) +
  
  # Temperature: upper-left
  geom_text(
    data = env_grid,
    aes(
      x = xmin + (xmax - xmin) * 0.25,
      y = ymin + (ymax - ymin) * 0.80,
      label = round(temp_bin)
    ),
    size = 5,
    col="red"
  ) +
  
  # Precipitation: upper-right
  geom_text(
    data = env_grid,
    aes(
      x = xmin + (xmax - xmin) * 0.75,
      y = ymin + (ymax - ymin) * 0.80,
      label = round(prec_bin)
    ),
    size = 5,
    col="blue"
  )

ggsave(filename = "env_grid.pdf")
